﻿namespace Task1
{
    public class SqlRepository
    {
        public void Create(string password) { }
    }
}