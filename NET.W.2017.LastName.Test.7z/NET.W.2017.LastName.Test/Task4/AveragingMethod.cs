﻿namespace Task4
{
    public enum AveragingMethod
    {
        Mean,
        Median
    }
}